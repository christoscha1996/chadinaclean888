export default function ChadinaSite() {
  return (
    <main className="min-h-screen bg-black text-white font-sans text-center p-12">
      <h1 className="text-5xl font-bold text-pink-500">CHADINA</h1>
      <p className="mt-4 text-lg text-gray-300">She doesn’t chase pumps. Pumps chase her.</p>
    </main>
  );
}
